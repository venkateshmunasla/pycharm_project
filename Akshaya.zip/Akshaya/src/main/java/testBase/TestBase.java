package testBase;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;




public class TestBase {
	
	public static WebDriver driver;
	public static Properties config=new Properties();
	public static Properties org=new Properties();
	public static FileInputStream fis_config,fis_org;
	
	//loading property files
public TestBase() throws IOException {
			
			
try {
	fis_config= new FileInputStream("D:\\eclipse workspace\\Akshaya\\properties\\config.properties");
	config.load(fis_config);
	fis_org=new FileInputStream("D:\\eclipse workspace\\Akshaya\\properties\\org.properties");
	org.load(fis_org);
   } catch (Exception e) {
	e.printStackTrace();
			}
			
	}
	
//Open Browser
public void openbrowser(String browser) {
	if(browser.equals("Chrome")) {
    System.setProperty("webdriver.chrome.driver", "C:\\Users\\suvar\\Downloads\\chromedriver_win32\\chromedriver.exe");
    driver=new ChromeDriver();	
    System.out.println("Chrome launched successfully");
		      
	} 
	else if(browser.equals("Firefox")) {
	System.setProperty("webdriver.gecko.driver", "D:\\geckodriver.exe");
	driver= new FirefoxDriver();
	System.out.println("firefox launched successfully");
				
	}
			driver.manage().window().maximize();
        	driver.manage().deleteAllCookies();
    		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		}
		
//Get Url
public void openurl(WebDriver driver,String url) {
			
	try {
	driver.get(url);
		} catch (Exception e) {
			e.printStackTrace();
		}
		}
		
//Click
public void click(WebDriver driver,String xpath) {
			
	
		try {
			driver.findElement(By.xpath(xpath)).click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  
		}
		
		
//Sendkeys
public void sendkey(WebDriver driver, String xpath,String value) {
			
	try {
			driver.findElement(By.xpath(xpath)).sendKeys(value);
		} catch (Exception e) {
			e.printStackTrace();
		}
		}
//mouse over
public void mouseover(WebDriver driver, String xpath) {
	try {
		Actions ac=new Actions(driver);
		WebElement obj = driver.findElement(By.xpath(xpath));
		ac.moveToElement(obj).perform();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
// WebElement List
public void webelementlist(WebDriver driver, String xpath) {
	Actions ac=new Actions(driver);
	WebElement obj = driver.findElement(By.xpath(xpath));
	ac.moveToElement(obj).perform();
	List<WebElement> Options = driver.findElements(By.xpath("(//a9starts-with[@class,'drpdwn-menu-list-link'])"));
	for (int i = 0; i < Options.size(); i++) {
		String txt = Options.get(i).getText();
		Reporter.log(txt,true);
		
	}
	}

//DropDown
public void dropdown(WebDriver driver, String xpath, String text) {
	

	try {
		Select sel=new Select(driver.findElement(By.xpath(xpath)));
		sel.selectByVisibleText(text);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

}

//ScreenShot
public void screenshot(WebDriver driver,String Xpath,String filepath) throws Exception {
	try {
		File f1=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(f1, new File(filepath));
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}

//Drag and Drop
public void draganddrop(WebDriver driver,String xpath, int index) {
	try {
		driver.switchTo().frame(index);
		Actions a= new Actions(driver);
		a.dragAndDrop(driver.findElement(By.xpath(xpath)),
		 driver.findElement(By.xpath(xpath))).build().perform();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
//calender
	public void calender(WebDriver driver,String xpath,int value) {
		 try {
			WebElement Cal= driver.findElement(By.xpath(xpath));
			 int value1=10/10/1989;;
			   	 JavascriptExecutor jse= (JavascriptExecutor)driver;
			 String script= "arguments[0].setAttribute('value','"+value1+"');";
			 jse.executeScript(script, Cal);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
//	alert in web driver
		 public void alert(WebDriver driver) {
			 try {
				Alert a= driver.switchTo().alert();
				a.dismiss();
				//a.accept();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	 }
		 
//Robot Class
		 public void robotclass(WebDriver driver) throws Exception {
			 try {
				Robot r=new Robot();
				 r.keyPress(KeyEvent.KEY_PRESSED);
				 r.keyRelease(KeyEvent.KEY_RELEASED);
				 r.keyPress(KeyEvent.VK_ENTER);
				 r.keyPress(KeyEvent.VK_ENTER);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
		
	}
	

//implicity wait
		 public void implicitywait(WebDriver driver) {
			 try {
				driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
}

//Excipility wait

		 public void excipilitywait(WebDriver driver,String xpath) {
			try {
				 WebDriverWait wait= new WebDriverWait(driver,15);
				 wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));
				 driver.findElement(By.xpath(xpath)).click();
			} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
			}
		    }
//File upload
 public void fileupload(WebDriver driver,String xpath,String filepath) {
	 try {
		WebElement fileinput=driver.findElement(By.xpath(xpath));
		 fileinput.sendKeys(filepath);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
 }
		
public void navigateBack(WebDriver driver) {
	try {
		driver.navigate().back();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
		
}


