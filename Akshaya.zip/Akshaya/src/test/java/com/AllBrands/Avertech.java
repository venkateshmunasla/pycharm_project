package com.AllBrands;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import testBase.TestBase;

public class Avertech extends TestBase{

	public Avertech() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	} 
	@BeforeClass
	@Parameters("browser")
public void startexecution(String browser) {
	openbrowser(browser);
}   @Test
	public void Allproducts() {
		openurl(driver, org.getProperty("url"));
	mouseover(driver, config.getProperty("Brands"));	
	List<WebElement>element=driver.findElements(By.xpath("(//a[starts-with(@href,'http://akshayacomputers.com/brands_show')])"));
	System.out.println("all elements are=" + element.size());
	WebElement dell=driver.findElement(By.xpath("//a[@href='http://akshayacomputers.com/brands_show/18']"));
	System.out.println("avertech is clicked");
	dell.click();

		List<WebElement> elm= driver.findElements(By.xpath("(//h4/a[starts-with(@href,'http://akshayacomputers.com/products_sh')])"));
		System.out.println( "available products are="+elm.size());
		
		for(int a=1;a<=elm.size();a++) {
			//All Product items run one by one and print product name 		
		WebElement element2=driver.findElement(By.xpath("(//h4/a[starts-with(@href,'http://akshayacomputers.com/products_sh')])["+a+"]"));
		System.out.println("["+a+"].Product Name:"+element2.getText());
//All product items click at product image one by one     		
		WebElement element3=driver.findElement(By.xpath("(//a/img[@class='lazy first-image'])["+a+"]"));
		element3.click();
		System.out.println("product item image click");
//click on Add To Cart    		
        WebElement element4=driver.findElement(By.xpath("(//input[starts-with(@url,'http://akshayacomputers.com/cart/add_cart_without_login')])[1]"));
		element4.click();
	driver.navigate().back();
	System.out.println("navigate to back completed");
		}
} 


}
