package com.Akshaya;

import java.io.IOException;
import java.util.List;

import javax.swing.Action;
import javax.swing.JSlider;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import testBase.TestBase;

@SuppressWarnings("unused")
public class Pricerangebar  extends TestBase{

	public Pricerangebar() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	} 
	@BeforeClass
	@Parameters("browser")
public void startexecution(String browser) {
	openbrowser(browser);
}   @Test
	public void Allproducts() {
		openurl(driver, org.getProperty("url"));
	mouseover(driver, config.getProperty("Brands"));	
	List<WebElement>element=driver.findElements(By.xpath("(//a[starts-with(@href,'http://akshayacomputers.com/brands_show')])"));
	System.out.println("all elements are=" + element.size());
	
	for(int i=1;i<=element.size();i++) {
		WebElement elm=driver.findElement(By.xpath("(//a[starts-with(@href,'http://akshayacomputers.com/brands_show')])[" + i + "]"));
		System.out.println( "Brands"+elm.getText());
		elm.click();
	/*WebElement slide=driver.findElement(By.xpath("//div[@id='price_range']"));
     //JSlider slider=new JSlider(2500,64500);
	Actions act=new Actions(driver)	;
	Action action = (Action) act.dragAndDropBy(slide, 2000, 65000).build();
    ((Actions) action).perform();*/
		
		
		WebElement node1=driver.findElement(By.xpath("(//span[@tabindex='0'])[1]"));					
		Actions ac=new Actions(driver);
		ac.click(node1).perform();
		for (int l = 0; l < 21; l++) {
		ac.sendKeys(Keys.ARROW_RIGHT).perform();
}
		WebElement node2=driver.findElement(By.xpath("(//span[@tabindex='0'])[2]"));					
		ac.click(node2).perform();
		for (int m = 0; m < 21; m++) {
		ac.sendKeys(Keys.ARROW_LEFT).perform();
		
}
		

}}}
