package com.Akshaya;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import testBase.TestBase;

public class Offers extends TestBase{

	public Offers() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	} 
	@BeforeClass
	@Parameters("browser")
public void startexecution(String browser) {
	openbrowser(browser);
}   @Test
	public void Allproducts() {
		openurl(driver, org.getProperty("url"));
		click(driver,config.getProperty("Offers"));
		//click(driver,config.getProperty("OFCLocation"));
		String location=driver.findElement(By.xpath("//i[@class='fa fa-map-marker']")).getText();
		if(location.equals("#Plot no-6, Hill Colony, Opp. Ganesh temple, Vanasthalipuram.")) {
			System.out.println("Address is matched");
			}
		else {
			System.out.println("Adress is not matched");
		}

	//click(driver,config.getProperty("OFCcompanyPhnNo"));
	 String phnno=driver.findElement(By.xpath("//span[text()='+91 9000677245']")).getText();
	 if(phnno.equals("+91 9000677245")) {
		 System.out.println("phone number matched");
	 }
	 else {
		 System.out.println("phone doesnot matched");
	 }

	//click(driver,config.getProperty("OFCGmail"));
	String gmail=driver.findElement(By.xpath("//span[text()='info@akshayacomputers.com']")).getText();
	if(gmail.equals("info@akshayacomputers.com")) {
		System.out.println("gmail matched");
	}
	else {
		System.out.println("gmail is dont matched");
	}
	sendkey(driver,config.getProperty("OFCname"),org.getProperty("firstname"));
	sendkey(driver,config.getProperty("OFCEmail"),org.getProperty("email"));
	sendkey(driver,config.getProperty("OFCPhnNo"),org.getProperty("phnno"));
	sendkey(driver,config.getProperty("OFCComment"),org.getProperty("comment"));
	click(driver,config.getProperty("OFCSubmit"));
	System.out.println("offers detials submited");
}}
