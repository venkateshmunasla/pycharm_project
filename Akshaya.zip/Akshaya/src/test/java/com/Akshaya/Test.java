package com.Akshaya;

import java.util.List;

import org.apache.poi.util.SystemOutLogger;
import org.openqa.selenium.By;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;

public class Test {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
	    WebDriver driver = new ChromeDriver();	
	    System.out.println("Chrome launched successfully");
	    driver.get("http://akshayacomputers.com/brands_show");
	    driver.manage().window().maximize();
	    List<WebElement> checkbox=driver.findElements(By.xpath("//input[@type='checkbox']"));
		System.out.println("all checkboxes are="+checkbox.size());
		for (int a = 1; a <=checkbox.size(); a++) {
		WebElement product=driver.findElement(By.xpath("(//span[@class='sf-name'])["+a+"]"));
		product.click();
		System.out.println("["+a+"].productname="+product.getText());
	//product is click and add to cart	
		List<WebElement> products=driver.findElements(By.xpath("//div[@class='img2']"));
		System.out.println("all products images are"+products.size());
		Thread.sleep(3000);
		
		
		for (int a1 = 1; a1 <= products.size(); a1++) {
			//WebElement productitem=driver.findElement(By.xpath("(//img[contains(@class,'lazy first-image productImg')])"));
WebElement productname=driver.findElement(By.xpath("((//h4/a[starts-with(@href,'http://akshayacomputers.com/products_sh/')]))["+a1+"]"));
System.out.println("["+a1+"]productname is click"+productname.getText());
productname.click();
			driver.findElement(By.xpath("//input[@value='ADD TO CART']")).click();
			driver.navigate().back();
		
		
		
		
}

}}}
