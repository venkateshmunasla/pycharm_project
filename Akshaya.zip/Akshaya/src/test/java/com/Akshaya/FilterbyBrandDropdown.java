package com.Akshaya;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import testBase.TestBase;

public class FilterbyBrandDropdown extends TestBase{

	public FilterbyBrandDropdown() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	} 
	@BeforeClass
	@Parameters("browser")
public void startexecution(String browser) {
	openbrowser(browser);
}   @Test
	public void Allproducts() throws Exception {
		openurl(driver, org.getProperty("url"));
	mouseover(driver, config.getProperty("Brands"));	
	List<WebElement>element=driver.findElements(By.xpath("(//a[starts-with(@href,'http://akshayacomputers.com/brands_show')])"));
	System.out.println("all elements are=" + element.size());
	for(int i=1;i<=element.size();i++) {
		WebElement elm=driver.findElement(By.xpath("(//a[starts-with(@href,'http://akshayacomputers.com/brands_show')])[" + i + "]"));
		System.out.println( "Brands"+elm.getText());
		elm.click();
//no of checkboxes		
		List<WebElement> checkbox=driver.findElements(By.xpath("//input[@type='checkbox']"));
		System.out.println("all checkboxes are="+checkbox.size());
		for (int a = 1; a <=checkbox.size(); a++) {
		WebElement product=driver.findElement(By.xpath("(//span[@class='sf-name'])["+a+"]"));
		product.click();
		System.out.println("["+a+"].productname="+product.getText());
	//product is click and add to cart	
		List<WebElement> products=driver.findElements(By.xpath("//div[@class='img2']"));
		System.out.println("all products images are"+products.size());
		Thread.sleep(3000);
		}
		
		
		
		
		
		
		
		
}}
}