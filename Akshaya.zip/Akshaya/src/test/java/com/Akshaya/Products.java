package com.Akshaya;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import testBase.TestBase;

public class Products extends TestBase{

	public Products() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}
	@BeforeClass
	@Parameters("browser")
public void startexecution(String browser) {
	openbrowser(browser);
}   @Test
	public void Allproducts() {
		openurl(driver, org.getProperty("url"));
	mouseover(driver, config.getProperty("Products"));	
	List<WebElement>element=driver.findElements(By.xpath("(//a[starts-with(@href,'http://akshayacomputers.com/products_show')])"));
	int optioncount=element.size();
System.out.println("Total Sub Products size="+optioncount);
for(int a=1 ;a<=optioncount;a++) {
	WebElement option=driver.findElement(By.xpath("(//a[@class='drpdwn-menu-list-link'])["+a+"]"));
	String element2=option.getText();
	System.out.println("SubProducts="+element2);
option.click();
	 List<WebElement> opt=driver.findElements(By.xpath("//img[@class='lazy first-image productImg']"));
	int optcount=opt.size();
	System.out.println("Items List="+optcount);
	for(int b=1;b<=optcount;b++) {
   WebElement img=driver.findElement(By.xpath("(//img[@class='lazy first-image productImg'])["+b+"]"));
    img.click();
    System.out.println("item is clicked=" + b);
    WebElement we= driver.findElement(By.id("button-cart"));
    we.click();
    System.out.println("cart button is clicked");
    driver.navigate().back();
	}
	
	
	
}}}
