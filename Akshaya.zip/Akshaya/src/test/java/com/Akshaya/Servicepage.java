package com.Akshaya;

import java.io.IOException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import testBase.TestBase;

public class Servicepage extends TestBase{

	public Servicepage() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	} 
	@BeforeClass
	@Parameters("browser")
public void startexecution(String browser) {
	openbrowser(browser);
}   @Test
	public void Allproducts() {
		openurl(driver, org.getProperty("url"));
		click(driver,config.getProperty("Services"));
		sendkey(driver,config.getProperty("SVUsername"),org.getProperty("firstname"));
		sendkey(driver,config.getProperty("SVEmailid"),org.getProperty("SVEmailid"));
		sendkey(driver,config.getProperty("svcontact"),org.getProperty("phnno"));
		dropdown(driver,config.getProperty("SVservices"),"Desktop Repair");
		sendkey(driver, config.getProperty("SVComment"),org.getProperty("comment"));
		click(driver,config.getProperty("SVsubmit"));
		System.out.println("successfully submited  service detials");
		navigateBack(driver);
		
		click(driver,config.getProperty("svAbout"));
		System.out.println("about us page open");
		navigateBack(driver);
		
		click(driver,config.getProperty("SVcontact"));
		System.out.println("contact page open");
		navigateBack(driver);
		
		click(driver,config.getProperty("SVBookticket"));
		System.out.println("book titcket page opene");
		navigateBack(driver);
		
		click(driver,config.getProperty("SVBrands"));
		System.out.println("view all brands");		
	    navigateBack(driver);
		
	    click(driver,config.getProperty("SVAccount"));
		System.out.println("account open");
		navigateBack(driver);
		
		click(driver,config.getProperty("SVOrderHistory"));
		System.out.println("view all history detials");
		navigateBack(driver);
		
		click(driver,config.getProperty("SVWishList"));
		System.out.println("view all wish list");
		navigateBack(driver);

		click(driver,config.getProperty("SVFacebook"));
		System.out.println("Facebook account open");
		
		driver.getWindowHandle();
		click(driver,config.getProperty("SVTwiter"));
		System.out.println("Twitter account open");
		
		
		click(driver,config.getProperty("SVGoogle"));
		System.out.println("google account open");
		
		
		click(driver,config.getProperty("SVTumbler"));
		System.out.println("Tumbler account open");
		
		
		click(driver,config.getProperty("SVInstagram"));
		System.out.println("instagram account open");
		
		
		click(driver,config.getProperty("SVYoutube"));
		System.out.println("youtube open");
		
	
	

}}
