package com.Akshaya;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import testBase.TestBase;

public class Homepage extends TestBase{
	

		public Homepage() throws IOException {
				super();
			}
			@BeforeClass
			@Parameters("browser")
			public void startexecution(String browser) {
				openbrowser(browser);
			}
		//email and phone number verify
			@Test
		   public void verifyphn_email() {
					openurl(driver,org.getProperty("url"));
					String txt=driver.findElement(By.xpath("(//a[@class='con2'])[1]")).getText();
					System.out.println(txt);
					String etxt = "9000677245";
					if (etxt.equals(txt)) {
						System.out.println("Phone number matched : Test Passed");
					} else {
						System.out.println("Phone number not matched : Test Failed");
					}

				String txt1=driver.findElement(By.xpath("(//a[@class='con2'])[2]")).getText();
				System.out.println(txt1);
				String etxt1="info@akshayacomputers.com";
				if(etxt1.equals(txt1)) {
					System.out.println("Email id: Matched");
				}
				else {
					System.out.println("Email id:not Matched");
				}		
				}
		//Registration account
			@Test
		    public void registration() {
			openurl(driver,org.getProperty("url"));
			click(driver,config.getProperty("Register"));
			sendkey(driver,config.getProperty("RG1stName"),org.getProperty("firstname"));
			sendkey(driver,config.getProperty("RGLLastName"),org.getProperty("lastname"));
			sendkey(driver,config.getProperty("RGPhoneNumber"),org.getProperty("phnno"));
			sendkey(driver,config.getProperty("RGEmail"),org.getProperty("email"));
			sendkey(driver,config.getProperty("RGPassword"),org.getProperty("password"));
			sendkey(driver,config.getProperty("RGCnfPassword"),org.getProperty("cpassword"));
			click(driver,config.getProperty("RGSubmit"));
			System.out.println("registation completed");
			String txt=driver.findElement(By.xpath("//div[@class='alert alert-success alert-dismissible']")).getText();
			String otp = txt.substring(txt.length() - 6);
			System.out.println(otp);
			sendkey(driver,config.getProperty("RGOtp"),otp);
			click(driver,config.getProperty("RGOtpSubmit"));
			alert(driver);
			System.out.println("opt submited");

		}

		//Login suvarna account
			@Test
		     public void login() {
		    	 click(driver,config.getProperty("HMLogin"));
		    	 sendkey(driver,config.getProperty("Emailid"),org.getProperty("emailid"));
		    	 sendkey(driver,config.getProperty("Password"),org.getProperty("password"));
		    	 click(driver,config.getProperty("Submit"));
		    	 System.out.println("suvarna account login");
		//Logout suvarna account
		    	 mouseover(driver,config.getProperty("suvvilogin"));
		    	 click(driver,config.getProperty("suvvilogout"));
		    	 System.out.println("suvvi account logout success");
		 
		    	 
		//Forget password
		    	 click(driver,config.getProperty("HMLogin"));
		    	 sendkey(driver,config.getProperty("Forgetpasswordemailid"),org.getProperty("email"));
		    	 click(driver,config.getProperty("forgetsubmit"));
		    	 navigateBack(driver);
		    	 System.out.println("forget password element working");

		     }
		     
		// Check Wishlist and navigate to back
			     @Test
		        public void wishlist() {
			      click(driver,config.getProperty("HMLogin"));
			       navigateBack(driver);
		           System.out.println("back to menu success full completed");
			}
}
